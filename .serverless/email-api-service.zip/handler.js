const AWS = require("aws-sdk");
const ses = new AWS.SES();

exports.sendEmail = async (event) => {
  const params = {
    Source: "esaldana@bluepeople.com",
    Destination: {ToAddresses: ["psilva@bluepeople.com"]},
    Message: {
      Subject: {Data: "A ñeñe"},
      Body: {
        Html: {
          Data: '<p>Hola mf picale aqui ajjajaja <a href="https://youtu.be/HpCCzYO0laA?feature=shared&t=138">hyperlink</a>.</p>',
        },
      },
    },
  };

  try {
    await ses.sendEmail(params).promise();
    return {statusCode: 200, body: JSON.stringify({message: "Email sent!"})};
  } catch (error) {
    return {statusCode: 500, body: JSON.stringify({error})};
  }
};
